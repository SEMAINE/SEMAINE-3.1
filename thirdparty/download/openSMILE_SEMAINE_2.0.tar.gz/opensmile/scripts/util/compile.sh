#!/bin/sh

gcc -lm htk-standardize.c -o htk-standardize

