#!/bin/sh

Pwd=`pwd`;
./autogen.sh ;
./autogen.sh ;
mkdir inst
./configure --prefix=$Pwd/inst --enable-static --disable-shared &&
make clean &&
make -j8 ; make install &&

echo ""
echo "build successfull. You can now use the inst/bin/SMILExtract binary."
echo ""

