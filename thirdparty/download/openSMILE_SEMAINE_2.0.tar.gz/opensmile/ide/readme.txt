This folder contains projects for integrated development environments.
======================================================================


Note: The DevC++ project (openSmile.dev) is outdated and should not be used.

== The folder "vs05" contains Visual Studio 2005 projects and solutions. ==

These are the preferred choice of building openSMILE / openEAR.
Several project and solutions are provided for various configurations.

a) openSmile.sln

This solution builds the core library (openSmileLib) and a command-line executable (SMILExtract). This build has no third-party dependencies, thus building the solution is all you have to do. However, you will not have live audio input/output functionality. Portaudio is required for this (see b) ).

b) openSmilePA.sln

This solution builds the core library (openSmileLibPA) and a command-line executable (SMILExtractPA). This build depends on the PortAudio library for interfacing the sound card. The library can be obtained from http://www.portaudio.com/. In order to successfully build this solution, you must download pa_snapshot.tgz from http://www.portaudio.com/ and unpack the contents to the directory "thirdparty/". This should create a folder "portaudio/" in "thirdparty/" containing the portaudio source and build files. IMPORTANT: Before you attempt to open and compile openSmilePA.sln you must replace the portaudio Visual Studio project by an updated version included with openSMILE: copy the files portaudio.def and portaudio.vcproj from the folder "ide/vs05" into "thirdparty/portaudio/build/msvc" and overwrite the existing files. This configuration compiles portaudio with Windows Media Extensions (WME) API support only (DirectSound and ASIO are not supported). This should be ok for most standard consumer desktops with a standard PCI or USB soundcard. 
If you are working with professional equipment or require DirectSound support, you will need to modify the original (!) portaudio build project included in pa_snapshot.tgz to suit your needs. When doing so, please make sure to modify the output paths for the DLL and Import Library to ..\..\..\..\portaudio_x86.dll/lib (and ..\..\..\..\portaudio_x86Dbg.dll/lib for the Debug configuration). This will ensure that the openSmile build finds the required files. Please note that for ASIO support you need to get the ASIO SDK which is not included with portaudio. For DirectSound you will need to obtain the Microsoft DirectX SDK v9.0 or later. 
c) openSmileLibAll.*

These files are not intended for building windows binaries of openSMILE. They contain a collection of all files (.cpp/.hpp/...) contained (all wrappers to third-party dependencies, etc., which are not included in the standard windows build solutions). These project files / solutions are only indended for editing source code in Visual Studio, not for compiling / building. If you add new components, please add them to these projects *at least*. If you add standalone components, you might also consider adding the to openSmileLib and openSmileLibPA projects. 

  **Output files:**

All output binaries (DLL and EXE) are created in the top-level directory. SMILExtract.exe is the standalone version and SMILExtractPA.exe ist the version with portaudio support. The openSMILE libraries are called openSmileLib.dll and openSmileLibPA.dll accordingly. If you compile debug versions, your binaries are suffixed with "Dbg".


== The folder vs2005 contains Visual Studio 2005 Express projects ==
 
 These projects are outdated. Open the VS05 projects in VS 2005 Express instead. This should work.
 IMPORTANT: For VS2005 Express, the Platform SDK 2003 is required!
 You must add the include and library paths of the Windows Platform SDK 2003 Server to the project configuration (C/C++ -> General -> Additional includes / Linker -> General -> Additional Library Directories).
 
 

== The folder vs08 is currently empty == 
  
  It may one day contain Visual Studio 2008 projects and solutions. Meanwhile, you can convert the VS2005 solutions to VS2008 solutions. The spares the effort of maintaining two identical configuration files in the openSMIL repository. 


==== Further plans / TODO =====

Create an eclipse project for Unix/MacOs (windows/MinGW32 ??) systems, which uses autogen / configure / make to compile

