/*F******************************************************************************
 *
 * openSMILE - open Speech and Music Interpretation by Large-space Extraction
 *       the open-source Munich Audio Feature Extraction Toolkit
 * Copyright (C) 2008-2009  Florian Eyben, Martin Woellmer, Bjoern Schuller
 *
 *
 * Institute for Human-Machine Communication
 * Technische Universitaet Muenchen (TUM)
 * D-80333 Munich, Germany
 *
 *
 * If you use openSMILE or any code from openSMILE in your research work,
 * you are kindly asked to acknowledge the use of openSMILE in your publications.
 * See the file CITING.txt for details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 ******************************************************************************E*/


/*  openSMILE component:

example dataProcessor
writes data to data memory...

** you can use this as a template for custom dataProcessor components **

*/


#include <valbasedSelector.hpp>

#define MODULE "cValbasedSelector"

SMILECOMPONENT_STATICS(cValbasedSelector)

SMILECOMPONENT_REGCOMP(cValbasedSelector)
{
  SMILECOMPONENT_REGCOMP_INIT

  scname = COMPONENT_NAME_CVALBASEDSELECTOR;
  sdescription = COMPONENT_DESCRIPTION_CVALBASEDSELECTOR;

  // we inherit cDataProcessor configType and extend it:
  SMILECOMPONENT_INHERIT_CONFIGTYPE("cDataProcessor")
  
  SMILECOMPONENT_IFNOTREGAGAIN(
    ct->setField("threshold","selection threshold",1.0);
    ct->setField("idx", "index of element to use for selection",0);
    ct->setField("invert", "1=select when below threshold, 0=select when above threshold",0);
    ct->setField("removeIdx", "1=remove field with idx in output vector, 0=include it",0);
  )
  
  SMILECOMPONENT_MAKEINFO(cValbasedSelector);
}


SMILECOMPONENT_CREATE(cValbasedSelector)

//-----

cValbasedSelector::cValbasedSelector(const char *_name) :
  cDataProcessor(_name),
  myVec(NULL), idx(0), invert(0), removeIdx(0), threshold(0.0)
{
}

void cValbasedSelector::fetchConfig()
{
  cDataProcessor::fetchConfig();

  // load all configuration parameters you will later require fast and easy access to here:

  threshold = (FLOAT_DMEM)getDouble("threshold");
  // note, that it is "polite" to output the loaded parameters at debug level 2:
  SMILE_DBG(2,"threshold = %f",threshold);

  idx = getInt("idx");
  invert = getInt("invert");
  removeIdx = getInt("removeIdx");

}


/*
  Do what you like here... this is called after the input names and number of input elements have become available, 
  so you may use them here.
*/
/*
int cValbasedSelector::dataProcessorCustomFinalise()
{
  
  return 1;
}
*/


/* 
  Use setupNewNames() to freely set the data elements and their names in the output level
  The input names are available at this point, you can get them via reader->getFrameMeta()
  Please set "namesAreSet" to 1, when you do set names
*/
/*
int cValbasedSelector::setupNewNames(long nEl) 
{
  // namesAreSet = 1;
  return 1;
}
*/

/*
  If you don't use setupNewNames() you may set the names for each input field by overwriting the following method:
*/
/*
int cValbasedSelector::setupNamesForField(int i, const char*name, long nEl)
{
  // TODO: remove field with element(!) index idx
           // either remove full field if N==1, or copy field with N-1 elements


}
*/

int cValbasedSelector::myFinaliseInstance()
{
  int ret = cDataProcessor::myFinaliseInstance();
  if (ret) {
    // do all custom init stuff here... 
    // e.g. allocating and initialising memory (which is not used before, e.g. in setupNames, etc.),
    // loading external data, 
    // etc.

    // ...

  }
  return ret;
}


int cValbasedSelector::myTick(long long t)
{
  /* actually process data... */

  SMILE_IDBG(4,"tick # %i, processing value vector",t);

  // get next frame from dataMemory
  cVector *vec = reader->getNextFrame();
  if (vec == NULL) {
//printf("t=%i\n",t);
return 0;
}

  // add offset
  int i = idx;
  if (i >= vec->N) i = vec->N-1;
  FLOAT_DMEM val = vec->dataF[i];
  
  int copy = 0;
  if ( ((invert)&&(val < threshold)) || ((!invert)&&(val > threshold)) ) {
    copy = 1;
  }
  
  if (copy) {
    // TODO: remove threshold value if removeIdx == 1
    if (removeIdx == 1) {

      if (myVec==NULL) myVec = new cVector(vec->N-1 , vec->type);
      int j,n=0;
      for(j=0; j<vec->N; j++) {
        if (j!=i) myVec->dataF[n] = vec->dataF[j];
        n++;
      }
      // save to dataMemory
      writer->setNextFrame(myVec);
      //delete myVec;

    } else {
      // save to dataMemory
      writer->setNextFrame(vec);
    }
  }

  return 1;
}


cValbasedSelector::~cValbasedSelector()
{
  // cleanup...
  if (myVec!=NULL) delete myVec;
}

