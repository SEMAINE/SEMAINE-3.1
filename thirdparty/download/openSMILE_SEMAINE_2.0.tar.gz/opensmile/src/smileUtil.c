/*F******************************************************************************
 *
 * openSMILE - open Speech and Music Interpretation by Large-space Extraction
 *       the open-source Munich Audio Feature Extraction Toolkit
 * Copyright (C) 2008-2009  Florian Eyben, Martin Woellmer, Bjoern Schuller
 *
 *
 * Institute for Human-Machine Communication
 * Technische Universitaet Muenchen (TUM)
 * D-80333 Munich, Germany
 *
 *
 * If you use openSMILE or any code from openSMILE in your research work,
 * you are kindly asked to acknowledge the use of openSMILE in your publications.
 * See the file CITING.txt for details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 ******************************************************************************E*/

/*

Smile Util:

contains modular DSP functions
and other utility functions

*/

#include <smileUtil.h>
//#include <smileTypes.hpp>

/*******************************************************************************************
 ***********************=====   Sort functions   ===== **************************************
 *******************************************************************************************/

/* QuickSort algorithm for a float array with nEl elements */
void smileUtil_quickSort_float(float *arr, long nEl)
{
  #ifdef MAX_LEVELS
  #undef MAX_LEVELS
  #endif
  #define  MAX_LEVELS  300

  float piv;
  long beg[MAX_LEVELS], end[MAX_LEVELS],swap;
  long i=0, L, R;

  beg[0]=0; end[0]=nEl;
  while (i>=0) {
    L=beg[i]; R=end[i]-1;
    if (L<R) {
      piv=arr[L]; 
      while (L<R) {
        while (arr[R]>=piv && L<R) R--; if (L<R) arr[L++]=arr[R];
        while (arr[L]<=piv && L<R) L++; if (L<R) arr[R--]=arr[L]; }
      arr[L]=piv; beg[i+1]=L+1; end[i+1]=end[i]; end[i++]=L;
      if (end[i]-beg[i]>end[i-1]-beg[i-1]) {
        swap=beg[i]; beg[i]=beg[i-1]; beg[i-1]=swap;
        swap=end[i]; end[i]=end[i-1]; end[i-1]=swap;
      }
    } else { i--; }
  }
}

/* QuickSort algorithm for a double array with nEl elements */
void smileUtil_quickSort_double(double *arr, long nEl)
{
  #ifndef MAX_LEVELS
  #define MAX_LEVELS  300
  #endif

  double piv;
  long beg[MAX_LEVELS], end[MAX_LEVELS],swap;
  long i=0, L, R;
  
  beg[0]=0; end[0]=nEl;
  while (i>=0) {
    L=beg[i]; R=end[i]-1;
    if (L<R) {
      piv=arr[L];
      while (L<R) {
        while (arr[R]>=piv && L<R) R--; if (L<R) arr[L++]=arr[R];
        while (arr[L]<=piv && L<R) L++; if (L<R) arr[R--]=arr[L]; }
      arr[L]=piv; beg[i+1]=L+1; end[i+1]=end[i]; end[i++]=L;
      if (end[i]-beg[i]>end[i-1]-beg[i-1]) {
        swap=beg[i]; beg[i]=beg[i-1]; beg[i-1]=swap;
        swap=end[i]; end[i]=end[i-1]; end[i-1]=swap;
      }
    } else { i--; }
  }
}


/*******************************************************************************************
 ***********************=====   Math functions   ===== **************************************
 *******************************************************************************************/

/* check if number is power of 2 (positive or negative) */
long smileMath_isPowerOf2(long x)
{
  if (x==1) return 1;  // 1 is a power of 2
  if (((x&1) == 0)&&(x != 0)) { // only even numbers > 1
    x=x>>1;
    while ((x&1) == 0) { x=x>>1;  }
    return ((x==1)||(x==-1));
  }
  return 0;
}

/* round to nearest power of two */
long smileMath_roundToNextPowOf2(long x)
{
  // round x up to nearest power of 2
  unsigned long int flng = (unsigned long int)x;
  unsigned long int fmask = 0x8000;
  while ( (fmask & flng) == 0) { fmask = fmask >> 1; }
  // fmask now contains the MSB position
  if (fmask > 1) {
    if ( (fmask>>1)&flng ) { flng = fmask<<1; }
    else { flng = fmask; }
  } else {
    flng = 2;
  }

  return (long)flng;
}

/* round up to next power of 2 */
long smileMath_ceilToNextPowOf2(long x)
{
  long y = smileMath_roundToNextPowOf2(x);
  if (y<x) y *= 2;
  return y;
}

/* round down to next power of two */
long smileMath_floorToNextPowOf2(long x)
{
  long y = smileMath_roundToNextPowOf2(x);
  if (y>x) y /= 2;
  return y;
}

/*******************************************************************************************
 ***********************=====   DSP functions   ===== **************************************
 *******************************************************************************************/

  /*======= window functions ==========*/

/* rectangular window */
double * smileDsp_winRec(long _N)
{
  int i;
  double * ret = (double *)malloc(sizeof(double)*_N);
  double * x = ret;
  for (i=0; i<_N; i++) {
    *x = 1.0; x++;
  }
  return ret;
}

/* triangular window (non-zero endpoints) */
double * smileDsp_winTri(long _N)
{
  long i;
  double * ret = (double *)malloc(sizeof(double)*_N);
  double * x = ret;
  for (i=0; i<_N/2; i++) {
    *x = 2.0*(double)(i+1)/(double)_N;
    x++;
  }
  for (i=_N/2; i<_N; i++) {
    *x = 2.0*(double)(_N-i)/(double)_N;
    x++;
  }
  return ret;
}

/* powered triangular window (non-zero endpoints) */
double * smileDsp_winTrP(long _N)
{
  double *w = smileDsp_winTri(_N);
  double *x = w;
  long n; for (n=0; n<_N; n++) *x = *x * (*(x++));
  return w;
}

/* bartlett (triangular) window (zero endpoints) */
double * smileDsp_winBar(long _N)
{
  long i;
  double * ret = (double *)malloc(sizeof(double)*_N);
  double * x = ret;
  for (i=0; i<_N/2; i++) {
    *x = 2.0*(double)(i)/(double)(_N-1);
    x++;
  }
  for (i=_N/2; i<_N; i++) {
    *x = 2.0*(double)(_N-1-i)/(double)(_N-1);
    x++;
  }
  return ret;
}

/* hann(ing) window */
double * smileDsp_winHan(long _N)
{
  double i;
  double * ret = (double *)malloc(sizeof(double)*_N);
  double * x = ret;
  double NN = (double)_N;
  for (i=0.0; i<NN; i += 1.0) {
    *x = 0.5*(1.0-cos( (2.0*M_PI*i)/(NN-1.0) ));
    x++;
  }
  return ret;
}

/* hamming window */
double * smileDsp_winHam(long _N)
{
  double i;
  double * ret = (double *)malloc(sizeof(double)*_N);
  double * x = ret;
  double NN = (double)_N;
  for (i=0.0; i<NN; i += 1.0) {
/*    *x = 0.53836 - 0.46164 * cos( (2.0*M_PI*i)/(NN-1.0) ); */
    *x = 0.54 - 0.46 * cos( (2.0*M_PI*i)/(NN-1.0) );
    x++;
  }
  return ret;
}

/* half-wave sine window (cosine window) */
double * smileDsp_winSin(long _N)
{
  double i;
  double * ret = (double *)malloc(sizeof(double)*_N);
  double * x = ret;
  double NN = (double)_N;
  for (i=0.0; i<NN; i += 1.0) {
    *x = sin( (1.0*M_PI*i)/(NN-1.0) );
    x++;
  }
  return ret;
}

/* Lanczos window */
double * smileDsp_winLac(long _N)
{
  double i;
  double * ret = (double *)malloc(sizeof(double)*_N);
  double * x = ret;
  double NN = (double)_N;
  for (i=0.0; i<NN; i += 1.0) {
    *x = smileDsp_lcSinc( (2.0*i)/(NN-1.0) - 1.0 );
    x++;
  }
  return ret;
}

/* gaussian window ...??? */
double * smileDsp_winGau(long _N, double sigma)
{
  double i;
  double * ret = (double *)malloc(sizeof(double)*_N);
  double * x = ret;
  double NN = (double)_N;
  double tmp;
  if (sigma <= 0.0) sigma = 0.01;
  if (sigma > 0.5) sigma = 0.5;
  for (i=0.0; i<NN; i += 1.0) {
    tmp = (i-(NN-1.0)/2.0)/(sigma*(NN-1.0)/2.0);
    *x = exp( -0.5 * ( tmp*tmp ) );
    x++;
  }
  return ret;
}

/* Blackman window */
double * smileDsp_winBla(long _N, double alpha0, double alpha1, double alpha2)
{
  double i;
  double * ret = (double *)malloc(sizeof(double)*_N);
  double * x = ret;
  double NN = (double)_N;
  double tmp;
  for (i=0.0; i<NN; i += 1.0) {
    tmp = (2.0*M_PI*i)/(NN-1.0);
    *x = alpha0 - alpha1 * cos( tmp ) + alpha2 * cos( 2.0*tmp );
    x++;
  }
  return ret;

}

/* Bartlett-Hann window */
double * smileDsp_winBaH(long _N, double alpha0, double alpha1, double alpha2)
{
  double i;
  double * ret = (double *)malloc(sizeof(double)*_N);
  double * x = ret;
  double NN = (double)_N;
  for (i=0.0; i<NN; i += 1.0) {
    *x = alpha0 - alpha1 * fabs( i/(NN-1.0) - 0.5 ) - alpha2 * cos( (2.0*M_PI*i)/(NN-1.0) );
    x++;
  }
  return ret;
}

/* Blackman-Harris window */
double * smileDsp_winBlH(long _N, double alpha0, double alpha1, double alpha2, double alpha3)
{
  double i;
  double * ret = (double *)malloc(sizeof(double)*_N);
  double * x = ret;
  double NN = (double)_N;
  double tmp;
  for (i=0.0; i<NN; i += 1.0) {
    tmp = (2.0*M_PI*i)/(NN-1.0);
    *x = alpha0 - alpha1 * cos( tmp ) + alpha2 * cos( 2.0*tmp ) - alpha3 * cos( 3.0*tmp );
    x++;
  }
  return ret;
}

/* compute entropy of normalised values */
FLOAT_DMEM smileStat_entropy(FLOAT_DMEM *_vals, long N)
{
  FLOAT_DMEM e = 0.0;

  int i;

  FLOAT_DMEM dn = 0.0;
  FLOAT_DMEM min=0.0;
  FLOAT_DMEM l2 = (FLOAT_DMEM)log(2.0);

  for (i=0; i<N; i++) {
    dn += _vals[i];
    if (_vals[i] < min) min = _vals[i];
  }
  
  if (min < 0.0) {
    for (i=0; i<N; i++) {
      _vals[i] -= min;
      if (_vals[i] == 0.0) { _vals[i] = (FLOAT_DMEM)0.00001; dn += (FLOAT_DMEM)0.00001; }
      dn -= min;
    }
  }
  if (dn==0.0) dn = (FLOAT_DMEM)0.000001;

  for (i=0; i<N; i++) {
    FLOAT_DMEM ln = _vals[i] / dn;
    e += ln * (FLOAT_DMEM)log(ln) / l2;
  }

  return -e;
}


/* WAVE Header struct, valid only for PCM Files */
typedef struct {
  uint32_t	Riff;    /* Must be little endian 0x46464952 (RIFF) */
  uint32_t	FileSize;
  uint32_t	Format;  /* Must be little endian 0x45564157 (WAVE) */

  uint32_t	Subchunk1ID;  /* Must be little endian 0x20746D66 (fmt ) */
  uint32_t	Subchunk1Size;
  uint16_t	AudioFormat;
  uint16_t	NumChannels;
  uint32_t	SampleRate;
  uint32_t	ByteRate;
  uint16_t	BlockAlign;
  uint16_t	BitsPerSample;

  uint32_t	Subchunk2ID;  /* Must be little endian 0x61746164 (data) */
  uint32_t  Subchunk2Size;
} sRiffPcmWaveHeader;

typedef struct {
  uint32_t SubchunkID;
  uint32_t SubchunkSize;
} sRiffChunkHeader;


/* parse wave header from in-memory wave file pointed to by *raw */
int smilePcm_parseWaveHeader(void *raw, long long N, sWaveParameters *pcmParam)
{
  if ((raw != NULL)&&(pcmParam!=NULL)) {
    long long nRead;
    sRiffPcmWaveHeader *head;
    sRiffChunkHeader *chunkhead;
    int safetytimeout = 20;  // max <safetytimeout> chunks of 99kb size before 'data' chunk
    long long ptr = 0;

    head = (sRiffPcmWaveHeader *)raw;
    nRead = sizeof(sRiffPcmWaveHeader);
    if (N<nRead) nRead=N;
    raw = (char*)raw + nRead;
    ptr += nRead;
    if (nRead != sizeof(sRiffPcmWaveHeader)) {
      printf("smilePcm: Error reading %i bytes (header) from beginning of wave data! The given array is too short (N=%i)!",sizeof(sRiffPcmWaveHeader),(long)N);
      return 0;
    }

    /* Check for valid header , TODO: support other endianness */
	if ((head->Riff != 0x46464952) ||
		(head->Format != 0x45564157) ||
		(head->Subchunk1ID != 0x20746D66) ||
//		(head->Subchunk2ID != 0x61746164) ||
		(head->AudioFormat != 1) ||
		(head->Subchunk1Size != 16)) {
                            fprintf(stderr,"smilePcm:  Riff: %x\n  Format: %x\n  Subchunk1ID: %x\n  Subchunk2ID: %x\n  AudioFormat: %x\n  Subchunk1Size: %x",
                                        head->Riff, head->Format, head->Subchunk1ID, head->Subchunk2ID, head->AudioFormat, head->Subchunk1Size);
                            fprintf(stderr,"smilePcm: bogus wave/riff header or data/file in wrong format!");
                            return 0;
        }

    while ((head->Subchunk2ID != 0x61746164)&&(safetytimeout>0)) { // 0x61746164 = 'data'
      // keep searching for 'data' chunk:
      if (head->Subchunk2Size < 99999) {
        //char * tmp = (char*)malloc(head->Subchunk2Size);
        //nRead = (int)fread(tmp, 1, head->Subchunk2Size, filehandle);
        //nRead = head->Subchunk2Size + ...;
        char * tmp = (char *)raw; 
        raw = (char * )raw + head->Subchunk2Size;
        ptr += head->Subchunk2Size; 
        if (ptr > N) {
          fprintf(stderr,"smilePcm: less bytes read from wave data than indicated by Subchunk2Size (%i)! File seems broken!\n",head->Subchunk2Size);
          return 0;
        }
        free(tmp);
      } else {
        fprintf(stderr,"smilePcm: Subchunk2Size > 99999. This seems to be a bogus file!\n");
        return 0;
      }
      chunkhead = (sRiffChunkHeader *)raw;
      raw = (char*)raw + sizeof(sRiffChunkHeader);
      ptr += sizeof(sRiffChunkHeader);
      //nRead = (int)fread(&chunkhead, 1, sizeof(chunkhead), filehandle);
      if (ptr > N) {
        fprintf(stderr,"smilePcm: less bytes read from wave data than there should be (%i) while reading sub-chunk header! File seems broken!\n",sizeof(sRiffChunkHeader));
        return 0;
      }
      head->Subchunk2ID = chunkhead->SubchunkID;
      head->Subchunk2Size = chunkhead->SubchunkSize;
      safetytimeout--;
    }
    if (safetytimeout <= 0) {
      fprintf(stderr,"smilePcm: No 'data' subchunk found in wave-file among the first %i chunks! corrupt file?\n",safetytimeout);
      return 0;
    }
    
    pcmParam->sampleRate = head->SampleRate;
    pcmParam->nChan = head->NumChannels;
    pcmParam->nBPS = head->BlockAlign/head->NumChannels;
    pcmParam->nBits = head->BitsPerSample;
    pcmParam->nBlocks = head->Subchunk2Size / head->BlockAlign;
    pcmParam->blockSize = head->BlockAlign;

    // TODO: ???
    pcmParam->byteOrder = BYTEORDER_LE;
    pcmParam->memOrga = MEMORGA_INTERLV;
     
    return 1;

  }
  return 0;
}

// filename is optional and can be NULL ! It is used only for log messages.
int smilePcm_readWaveHeader(FILE *filehandle, sWaveParameters *pcmParam, const char *filename)
{
  if (filename == NULL) filename = "unknown";

  if ((filehandle != NULL)&&(pcmParam!=NULL)) {

    int nRead;
    sRiffPcmWaveHeader head;
    sRiffChunkHeader chunkhead;
    int safetytimeout = 20;  // max <safetytimeout> chunks of 99kb size before 'data' chunk

    fseek(filehandle, 0, SEEK_SET);
    nRead = (int)fread(&head, 1, sizeof(head), filehandle);
    if (nRead != sizeof(head)) {
      printf("smilePcm: Error reading %i bytes (header) from beginning of wave file '%s'! File too short??",sizeof(head),filename);
      return 0;
    }
    
    /* Check for valid header , TODO: support other endianness */
	if ((head.Riff != 0x46464952) ||
		(head.Format != 0x45564157) ||
		(head.Subchunk1ID != 0x20746D66) ||
//		(head.Subchunk2ID != 0x61746164) ||
		(head.AudioFormat != 1) ||
		(head.Subchunk1Size != 16)) {
                            fprintf(stderr,"smilePcm:  Riff: %x\n  Format: %x\n  Subchunk1ID: %x\n  Subchunk2ID: %x\n  AudioFormat: %x\n  Subchunk1Size: %x",
                                        head.Riff, head.Format, head.Subchunk1ID, head.Subchunk2ID, head.AudioFormat, head.Subchunk1Size);
                            fprintf(stderr,"smilePcm: bogus wave/riff header or file in wrong format ('%s')!",filename);
                            return 0;
        }

    while ((head.Subchunk2ID != 0x61746164)&&(safetytimeout>0)) { // 0x61746164 = 'data'
      // keep searching for 'data' chunk:
      if (head.Subchunk2Size < 99999) {
        char * tmp = (char*)malloc(head.Subchunk2Size);
        nRead = (int)fread(tmp, 1, head.Subchunk2Size, filehandle);
        if (nRead != head.Subchunk2Size) {
          fprintf(stderr,"smilePcm: less bytes read (%i) from wave file '%s' than indicated by Subchunk2Size (%i)! File seems broken!\n",nRead,filename,head.Subchunk2Size);
          return 0;
        }
        free(tmp);
      } else {
        fprintf(stderr,"smilePcm: Subchunk2Size > 99999. This seems to be a bogus file!\n");
        return 0;
      }
      nRead = (int)fread(&chunkhead, 1, sizeof(chunkhead), filehandle);
      if (nRead != sizeof(chunkhead)) {
        fprintf(stderr,"smilePcm: less bytes read (%i) from wave file '%s' than there should be (%i) while reading sub-chunk header! File seems broken!\n",nRead,filename,sizeof(chunkhead));
        return 0;
      }
      head.Subchunk2ID = chunkhead.SubchunkID;
      head.Subchunk2Size = chunkhead.SubchunkSize;
      safetytimeout--;
    }
    if (safetytimeout <= 0) {
      fprintf(stderr,"smilePcm: No 'data' subchunk found in wave-file among the first %i chunks! corrupt file?\n",safetytimeout);
      return 0;
    }
    
    pcmParam->sampleRate = head.SampleRate;
    pcmParam->nChan = head.NumChannels;
    pcmParam->nBPS = head.BlockAlign/head.NumChannels;
    pcmParam->nBits = head.BitsPerSample;
//    p->bits = head.BitsPerSample;
//    SMILE_DBG(5,"bits per sample = %i",head.BitsPerSample);
//    pcmParam.sampleType = pcmBitsToSampleType( head.BitsPerSample, BYTEORDER_LE, 0 );
/*
    if (head.NumChannels * head.BitsPerSample / 8 != head.BlockAlign) {
      FEATUM_ERR_FATAL(0,"Error reading wave file header: head.BlockAlign != head.NumChannels * head.BitsPerSample / 8");
      return 0;
    }
    */
    pcmParam->nBlocks = head.Subchunk2Size / head.BlockAlign;
    pcmParam->blockSize = head.BlockAlign;

    // TODO: ???
    pcmParam->byteOrder = BYTEORDER_LE;
    pcmParam->memOrga = MEMORGA_INTERLV;

    //pcmDataBegin = ftell(filehandle);

    return 1;
  }
  return 0;
}

/****** debug helper functions ******/

/* these functions are not safe and should only be used for data output during debugging ! */

#include <stdio.h>

void saveDoubleVector_csv(const char * filename, double * vec, long N, int append)
{
  FILE * f = NULL;
  if (append)
	f = fopen(filename,"a");
  else
	f = fopen(filename,"w");

  if (f!=NULL) {
    long i;
	for (i=0; i<N-1; i++) 
      fprintf(f, "%f,", vec[i]);
	fprintf(f, "%f\n", vec[i]);
	fclose(f);
  }
}

void saveFloatVector_csv(const char * filename, float * vec, long N, int append)
{
  FILE * f = NULL;
  if (append)
	f = fopen(filename,"ab");
  else
	f = fopen(filename,"wb");

  if (f!=NULL) {
    long i;
	for (i=0; i<N-1; i++) 
      fprintf(f, "%f,", vec[i]);
	fprintf(f, "%f\n", vec[i]);
	fclose(f);
  }
}


void saveDoubleVector_bin(const char * filename, double * vec, long N, int append)
{
  FILE * f = NULL;
  if (append)
	f = fopen(filename,"ab");
  else
	f = fopen(filename,"wb");

  if (f!=NULL) {
    fwrite(vec, sizeof(double)*N, 1, f);
	fclose(f);
  }
}

void saveFloatVector_bin(const char * filename, float * vec, long N, int append)
{
  FILE * f = NULL;
  if (append)
	f = fopen(filename,"ab");
  else
	f = fopen(filename,"wb");

  if (f!=NULL) {
    fwrite(vec, sizeof(float)*N, 1, f);
	fclose(f);
  }
}

