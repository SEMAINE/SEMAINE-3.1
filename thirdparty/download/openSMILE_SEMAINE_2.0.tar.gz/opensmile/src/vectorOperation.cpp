/*F******************************************************************************
 *
 * openSMILE - open Speech and Music Interpretation by Large-space Extraction
 *       the open-source Munich Audio Feature Extraction Toolkit
 * Copyright (C) 2008-2009  Florian Eyben, Martin Woellmer, Bjoern Schuller
 *
 *
 * Institute for Human-Machine Communication
 * Technische Universitaet Muenchen (TUM)
 * D-80333 Munich, Germany
 *
 *
 * If you use openSMILE or any code from openSMILE in your research work,
 * you are kindly asked to acknowledge the use of openSMILE in your publications.
 * See the file CITING.txt for details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 ******************************************************************************E*/


/*  openSMILE component:

do elementary operations on vectors 
(i.e. basically everything that does not require history or context,
 everything that can be performed on single vectors w/o external data (except for constant parameters, etc.))

*/



#include <vectorOperation.hpp>

#define MODULE "cVectorOperation"


SMILECOMPONENT_STATICS(cVectorOperation)

SMILECOMPONENT_REGCOMP(cVectorOperation)
{
  SMILECOMPONENT_REGCOMP_INIT
  scname = COMPONENT_NAME_CVECTOROPERATION;
  sdescription = COMPONENT_DESCRIPTION_CVECTOROPERATION;

  // we inherit cVectorProcessor configType and extend it:
  SMILECOMPONENT_INHERIT_CONFIGTYPE("cVectorProcessor")

  // if the inherited config type was found, we register our configuration variables
  SMILECOMPONENT_IFNOTREGAGAIN( {} // <- this is only to avoid compiler warnings...
    // name append has a special role: it is defined in cDataProcessor, and can be overwritten here:
	// if you set description to NULL, the existing description will be used, thus the following call can
	// be used to update the default value:
    //ct->setField("nameAppend",NULL,"processed");
  ct->setField("operation","type of operation to perform:\n   norm = normalise vector length to 1\n   mul = multiply vector by param1\n   add = add param1 to each element","norm");
  ct->setField("param1","parameter 1",1.0);
  ct->setField("param2","parameter 2",1.0);
    // this is an example for adding an integer option:
	//ct->setField("inverse","1 = perform inverse FFT",0);
  )

  // The configType gets automatically registered with the config manger by the SMILECOMPONENT_IFNOTREGAGAIN macro
  
  // we now create out sComponentInfo, including name, description, success status, etc. and return that
  SMILECOMPONENT_MAKEINFO(cVectorOperation);
}

SMILECOMPONENT_CREATE(cVectorOperation)

//-----

cVectorOperation::cVectorOperation(const char *_name) :
  cVectorProcessor(_name),
  param1(0.0)
{

}

void cVectorOperation::fetchConfig()
{
  cVectorProcessor::fetchConfig();
  
  const char * op = getStr("operation");
  operation=VOP_NORMALISE;
  if (!strncmp(op,"nor",3)) {
    operation=VOP_NORMALISE;
  } else if (!strncmp(op,"mul",3)) {
    operation=VOP_MUL;
  } else if (!strncmp(op,"add",3)) {
    operation=VOP_ADD;
  } else {
    SMILE_IERR(1,"unknown operation '%s' specified in config file.",op);
  }

  param1 = (FLOAT_DMEM)getDouble("param1");
}

// a derived class should override this method, in order to implement the actual processing
int cVectorOperation::processVectorInt(const INT_DMEM *src, INT_DMEM *dst, long Nsrc, long Ndst, int idxi) // idxi=input field index
{
  // do domething to data in *src, save result to *dst
  // NOTE: *src and *dst may be the same...
  
  return 1;
}

// a derived class should override this method, in order to implement the actual processing
int cVectorOperation::processVectorFloat(const FLOAT_DMEM *src, FLOAT_DMEM *dst, long Nsrc, long Ndst, int idxi) // idxi=input field index
{
  // do domething to data in *src, save result to *dst
  // NOTE: *src and *dst may be the same...
  FLOAT_DMEM sum =0.0;
  long i;

  switch(operation) {

    case VOP_NORMALISE:

      // normalise all incoming vectors
      for (i=0; i<MIN(Nsrc,Ndst); i++) {
        sum+=src[i]*src[i];
      }
      if (sum <= 0.0) {
        sum = 1.0;
      }
      sum = sqrt(sum/(FLOAT_DMEM)(MIN(Nsrc,Ndst)));
      for (i=0; i<MIN(Nsrc,Ndst); i++) {
        dst[i] = src[i] / sum;
      }

      break;


    case VOP_ADD:
      for (i=0; i<MIN(Nsrc,Ndst); i++) {
        dst[i] = src[i] + param1;
      }
      break;

    case VOP_MUL:
      for (i=0; i<MIN(Nsrc,Ndst); i++) {
        dst[i] = src[i] * param1;
      }
      break;

    default:
      for (i=0; i<MIN(Nsrc,Ndst); i++) {
        dst[i] = src[i];
      }

  }
  return 1;
}

cVectorOperation::~cVectorOperation()
{
}

