/*******************************************************************************
* openSMILE
*  - open Speech and Music Interpretation by Large-space Extraction -
* Copyright (C) 2008  Florian Eyben, Martin Woellmer, Bjoern Schuller
* 
* Institute for Human-Machine Communication
* Technische Universitaet Muenchen (TUM)
* D-80333 Munich, Germany
*
* If you use openSMILE or any code from openSMILE in your research work,
* you are kindly asked to acknowledge the use of openSMILE in your publications.
* See the file CITING.txt for details.
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*******************************************************************************/


/*
*  TumFeatureExtractor.cpp
*  semaine
*  
*/
#include <smileCommon.hpp>

#ifdef HAVE_SEMAINEAPI


#include <TumFeatureExtractor.h>

#undef MODULE
#define MODULE "TumFeatureExtractor"

#include <cstdlib>
#include <sstream>

#include <semaine/util/XMLTool.h>
#include <semaine/datatypes/xml/EMMA.h>
#include <semaine/datatypes/xml/EmotionML.h>
#include <semaine/datatypes/xml/SemaineML.h>

using namespace semaine::util;
using namespace semaine::datatypes::xml;
using namespace XERCES_CPP_NAMESPACE;

namespace semaine {
  namespace components {
    namespace smile {


    TumFeatureExtractor::TumFeatureExtractor(cComponentManager *_cMan, cConfigManager *_conf) throw(CMSException) : 
      ComponentForSmile("TumFeatureExtractor",_cMan,_conf,true,false),
      callbackRecv(NULL), emmaSender(NULL), featureSender(NULL), callbackReceiver(NULL)
    {
      if (_conf->isSet_f(myvprint("semaine.callbackRecv[%s]",getName().c_str()))) callbackRecv = _conf->getStr_f(myvprint("semaine.callbackRecv[%s]",getName().c_str()));

      if ((topicR != NULL)) {
        callbackReceiver = new XMLReceiver(topicR);
        receivers.push_back(callbackReceiver);
      } else {
        SMILE_WRN(1,"topicR == NULL in TumFeatureExtractor, please check semaineCfg section in config file (no voice data will be read from speech output for echo compensation).");
      }

      int period = 10; // ms

      if (topicW != NULL) {
        featureSender = new FeatureSender(topicW, "", getName(), period);
        //	featureSender = new FeatureSender("semaine.data.analysis.features.voice", "", getName(), period);

        waitingTime = period;
        senders.push_back(featureSender);
      } else {
        // TODO: use semaine exception here...
        SMILE_WRN(1,"topicW == NULL in TumFeatureExtractor, please check semaineCfg section in config file (no features will be sent now!).");
      }

      if (topicEmma != NULL) {
        emmaSender = new EmmaSender(topicEmma, getName());
        senders.push_back(emmaSender);
      } else {
        // TODO: use semaine exception here...
        SMILE_WRN(1,"topicEmma == NULL in TumFeatureExtractor, please check semaineCfg section in config file (no emma XML messages will be sent!).");
      }

      // Marc, 21 Dec 08: Deactivated, because it leads to dropped messages when the ASR
      // is on a different machine where the clock time is not the same.
      //featureSender->setTimeToLive(100); // discard messages after 100 ms

    }



    TumFeatureExtractor::~TumFeatureExtractor()
    {
      if (cMan != NULL) {
        cMan->requestAbort();
        smileThreadJoin( smileMainThread );
      }
    }

    SMILE_THREAD_RETVAL smileThreadRunner(void *_obj)
    {
      cComponentManager * __obj = (cComponentManager *)_obj;
      if (_obj != NULL) {
        __obj->runMultiThreaded(-1);
      }
      SMILE_THREAD_RET;
    }

    void TumFeatureExtractor::customStartIO() throw(CMSException)
    {
      if (cMan == NULL) { SMILE_ERR(1,"componentManager (cMan) is NULL, smileMainThread can not be started!"); }
      else {
        // main openSMILE initialisation
        cMan->createInstances(0); // 0 = do not read config (we already did that ..)

        /* connect all the feature senders / receivers, etc. */

        // get openSMILE component pointers by name from _cMan
        if (asink != NULL) setSmileAMQsink(cMan->getComponentInstance(asink));
        if (asrc != NULL) setSmileAMQsource(cMan->getComponentInstance(asrc)); 
        if (emmas != NULL) setSmileEMMAsender(cMan->getComponentInstance(emmas)); 

        if (amqsink != NULL) {
          amqsink->setFeatureSender(featureSender,&meta);
        } else {
          SMILE_WRN(1,"amqsink == NULL in TumFeatureExtractor, please check semaineCfg section in config file (no features will be sent now!).");
        }

        if (emmasender != NULL) {
          emmasender->setEmmaSender(emmaSender,&meta);
        } else {
          SMILE_WRN(1,"emmasender == NULL in TumFeatureExtractor, please check semaineCfg section in config file (no emma XML messages will be sent!).");
        }

        // start the smile main thread, and call run
        smileThreadCreate( smileMainThread, smileThreadRunner, (void*)cMan  );
      }
      
    }

    void TumFeatureExtractor::react(SEMAINEMessage * m) throw (std::exception) 
    {
      // use amqsource->writer to save data to dataMemory  (if configured to use source..)
      /*
      if (amqsource == NULL) {
      // TODO: use semaine exception here...
      SMILE_WRN(1,"amqsource == NULL in TumFeatureExtractor, please check semaineCfg section in config file (discarding received data!).");
      return;
      }
      */

      /*
      cDataWriter *writer = amqsource->getWriter();
      cVector *vec = amqsource->getVec();
      */

      // TOOD: parse Semaine Message and write features to dataMemory...
      // Problem: featureNames.....!! We must assign generic names like "feature01" to "featureNN" and update them after the first message.... yet, we also don't know how many features we will be receiving, if we have not received the first message... BIG PROBLEM!!

      printf("GOT MESSAGE\n");

      SEMAINEXMLMessage * xm = dynamic_cast<SEMAINEXMLMessage *>(m);
      if (xm == NULL) {
        throw MessageFormatException("expected XML message, got "+std::string(typeid(*m).name()));
      }

      XERCESC_NS::DOMDocument * doc = xm->getDocument();
      XERCESC_NS::DOMElement * callback = doc->getDocumentElement();
      if (XMLTool::getNamespaceURI(callback) != SemaineML::namespaceURI ||
        XMLTool::getLocalName(callback) != "callback") {
          throw MessageFormatException("Expected callback message, but found "+ XMLTool::getLocalName(callback) + " element in namespace " + XMLTool::getNamespaceURI(callback));
      }
      XERCESC_NS::DOMElement * event = XMLTool::getChildElementByLocalNameNS(callback, SemaineML::E_EVENT, SemaineML::namespaceURI);
      if (event != NULL) {
        std::string type = XMLTool::getAttribute(event, "type");
        std::string timeString = XMLTool::getAttribute(event, SemaineML::A_TIME);
        const char *ctype = type.c_str();
        printf("msg type='%s'\n",ctype);
        //char *ctime = timeString.cStr();
        cComponentMessage callbackMsg("semaineCallback",ctype);
        callbackMsg.sender = "TumFeatureExtractor";
        cMan->sendComponentMessage(callbackRecv,&callbackMsg);

      }


      /*
      SEMAINEFeatureMessage * fm = dynamic_cast<SEMAINEFeatureMessage *>(m);
      if (fm != NULL) {
      std::vector<float> features = fm->getFeatureVector();
      // TODO: get vecsize!!

      int i;
      for (i=0; i<vec->N; i++) { // limit to vecsize! !! TODO
      mat->dataF[i] = (FLOAT_DMEM)(features[i]);
      }
      writer->setNextFrame(vec);
      //TODO??
      }
      */	

    }

    void TumFeatureExtractor::act() throw(CMSException)
    {
      //	SMILE_DBG(1,"act() called!");

      // NOTE: act is unused here, since the activeMqSink components will handle the sending of data directly...


      //------------------------------------------------------------------------------------------------
      //	SMILE_DBG(9,"calling getFrame (id1=%i)",framerId1);

      // ++AMQ++  send (arousal, valence, interest) as EMMA
      /*
      char strtmp[50];
      sprintf(strtmp,"%.2f",a);
      std::string aroStr(strtmp);
      sprintf(strtmp,"%.2f",v);
      std::string valStr(strtmp);
      sprintf(strtmp,"%1.0f",i);
      std::string interestStr(strtmp);

      // Create and fill a simple EMMA EmotionML document
      DOMDocument * document = XMLTool::newDocument(EMMA::E_EMMA, EMMA::namespaceURI, EMMA::version);
      DOMElement * interpretation = XMLTool::appendChildElement(document->getDocumentElement(), EMMA::E_INTERPRETATION);
      XMLTool::setAttribute(interpretation, EMMA::A_START, "time not implemented");
      DOMElement * emotion = XMLTool::appendChildElement(interpretation, EmotionML::E_EMOTION, EmotionML::namespaceURI);
      if ((svmPredA != NULL)||(svmPredV != NULL)) {
      DOMElement * dimensions = XMLTool::appendChildElement(emotion, EmotionML::E_DIMENSIONS, EmotionML::namespaceURI);
      XMLTool::setAttribute(dimensions, EmotionML::A_SET, "valenceArousalPotency");
      if (svmPredA != NULL) {
      DOMElement * arousal = XMLTool::appendChildElement(dimensions, EmotionML::E_AROUSAL, EmotionML::namespaceURI);
      XMLTool::setAttribute(arousal, EmotionML::A_VALUE, aroStr);
      }
      if (svmPredV != NULL) {
      DOMElement * valence = XMLTool::appendChildElement(dimensions, EmotionML::E_VALENCE, EmotionML::namespaceURI);
      XMLTool::setAttribute(valence, EmotionML::A_VALUE, valStr);
      }
      }
      if (svmPredI != NULL) {
      DOMElement * category = XMLTool::appendChildElement(emotion, EmotionML::E_CATEGORY, EmotionML::namespaceURI);
      XMLTool::setAttribute(category, EmotionML::A_NAME, "interest");
      XMLTool::setAttribute(category, EmotionML::A_VALUE, interestStr);
      }

      // Now send it
      emmaSender->sendXML(document, meta.getTime());
      */

      /*}    else {
      // TODO: skip frame...
      }
      turntime = 0;


      }
      }
      #endif

      }
      */


    }


    } // namespace smile
  } // namespace components
} // namespace semaine


#endif // HAVE_SEMAINEAPI
